# Replacements

Three resolution paths demonstrated here:

- `Hero.svelte` — flat file, resolved via the `overrides::` entry in `replacements.mdix` → `src/lib/components/Hero.svelte`
- `lib/tokens.css` — nested file, its path here IS the target path under `target_root` → `src/lib/tokens.css`
- `constants.ts` — flat file, no override → resolved by basename search under `target_root`; created at `src/constants.ts` if no match exists, overwritten if one does

This file itself is excluded via `ignore::` in the manifest.
